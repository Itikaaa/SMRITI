import { describe, expect, it } from "vitest";
import { MAX_UPLOAD_BYTES, sanitizeFilename } from "./routers";

describe("SMRITI storage validation", () => {
  it("sanitizes unsafe filenames into safe storage path segments", () => {
    expect(sanitizeFilename("family photo (2026).jpg")).toBe("family-photo--2026-.jpg");
    expect(sanitizeFilename("   ")).toBe("upload");
  });

  it("keeps the upload contract explicit at 8 MB", () => {
    expect(MAX_UPLOAD_BYTES).toBe(8 * 1024 * 1024);
  });
});
