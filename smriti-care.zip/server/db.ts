import { desc, eq, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertPatientProfile,
  InsertStoredFile,
  InsertUser,
  patientProfiles,
  storedFiles,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined || user.openId === ENV.ownerOpenId) {
    values.role = user.role ?? "admin";
    updateSet.role = values.role;
  }
  values.lastSignedIn ??= new Date();
  updateSet.lastSignedIn ??= new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function getPatientProfile(caregiverId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(patientProfiles).where(eq(patientProfiles.caregiverId, caregiverId)).limit(1);
  return result[0];
}

export async function upsertPatientProfile(profile: InsertPatientProfile) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(patientProfiles).values(profile).onDuplicateKeyUpdate({
    set: {
      preferredName: profile.preferredName,
      age: profile.age ?? null,
      background: profile.background ?? null,
      language: profile.language,
      childrenNames: profile.childrenNames ?? null,
      favouriteThings: profile.favouriteThings ?? null,
      updatedAt: new Date(),
    },
  });
  return getPatientProfile(profile.caregiverId);
}

export async function listStoredFiles(caregiverId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(storedFiles).where(eq(storedFiles.caregiverId, caregiverId)).orderBy(desc(storedFiles.createdAt));
}

export async function insertStoredFile(file: InsertStoredFile) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(storedFiles).values(file);
  const result = await db.select().from(storedFiles).where(eq(storedFiles.fileKey, file.fileKey)).limit(1);
  return result[0];
}

export async function updateStoredFile(caregiverId: number, id: number, patch: Partial<Pick<InsertStoredFile, "purpose" | "patientProfileId" | "consentStatus" | "consentNote" | "consentRecordedAt">>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(storedFiles).set(patch).where(and(eq(storedFiles.id, id), eq(storedFiles.caregiverId, caregiverId)));
  const result = await db.select().from(storedFiles).where(and(eq(storedFiles.id, id), eq(storedFiles.caregiverId, caregiverId))).limit(1);
  return result[0];
}

export async function removeStoredFile(caregiverId: number, id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(storedFiles).where(and(eq(storedFiles.id, id), eq(storedFiles.caregiverId, caregiverId)));
  return { success: true } as const;
}
