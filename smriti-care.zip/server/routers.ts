import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { getPatientProfile, insertStoredFile, listStoredFiles, removeStoredFile, updateStoredFile, upsertPatientProfile } from "./db";
import { storagePut } from "./storage";

export const MAX_UPLOAD_BYTES = 8 * 1024 * 1024;
const uploadPurposes = ["memory-photo", "voice-note", "care-document", "other"] as const;

export function sanitizeFilename(filename: string) {
  return filename.trim().replace(/[^a-zA-Z0-9._-]/g, "-").slice(0, 120) || "upload";
}

const profileInput = z.object({
  preferredName: z.string().trim().min(1).max(120),
  age: z.number().int().min(1).max(120).nullable().optional(),
  background: z.string().max(6000).nullable().optional(),
  language: z.string().trim().min(1).max(40),
  childrenNames: z.string().max(2000).nullable().optional(),
  favouriteThings: z.string().max(2000).nullable().optional(),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  profile: router({
    get: protectedProcedure.query(({ ctx }) => getPatientProfile(ctx.user.id)),
    save: protectedProcedure.input(profileInput).mutation(({ ctx, input }) =>
      upsertPatientProfile({
        caregiverId: ctx.user.id,
        preferredName: input.preferredName,
        age: input.age ?? null,
        background: input.background ?? null,
        language: input.language,
        childrenNames: input.childrenNames ?? null,
        favouriteThings: input.favouriteThings ?? null,
      }),
    ),
  }),
  files: router({
    list: protectedProcedure.query(({ ctx }) => listStoredFiles(ctx.user.id)),
    upload: protectedProcedure
      .input(
        z.object({
          filename: z.string().min(1).max(255),
          mimeType: z.string().min(1).max(120),
          sizeBytes: z.number().int().positive().max(MAX_UPLOAD_BYTES),
          dataBase64: z.string().min(1),
          purpose: z.enum(uploadPurposes).default("other"),
          patientProfileId: z.number().int().positive().nullable().optional(),
          consentStatus: z.enum(["pending", "confirmed", "declined"]).default("pending"),
          consentNote: z.string().max(1000).nullable().optional(),
        }),
      )
      .mutation(async ({ ctx, input }) => {
        const data = Buffer.from(input.dataBase64, "base64");
        if (data.byteLength !== input.sizeBytes || data.byteLength > MAX_UPLOAD_BYTES) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "This file is larger than the supported 8 MB limit or was not encoded correctly." });
        }
        const profile = await getPatientProfile(ctx.user.id);
        if (input.patientProfileId && (!profile || profile.id !== input.patientProfileId)) {
          throw new TRPCError({ code: "FORBIDDEN", message: "That patient profile does not belong to this caregiver." });
        }
        const uploaded = await storagePut(`caregivers/${ctx.user.id}/smriti/${sanitizeFilename(input.filename)}`, data, input.mimeType);
        return insertStoredFile({
          caregiverId: ctx.user.id,
          patientProfileId: input.patientProfileId ?? profile?.id ?? null,
          consentStatus: input.consentStatus,
          consentNote: input.consentNote ?? null,
          consentRecordedAt: input.consentStatus === "confirmed" ? new Date() : null,
          fileKey: uploaded.key,
          fileUrl: uploaded.url,
          filename: input.filename,
          mimeType: input.mimeType,
          sizeBytes: input.sizeBytes,
          purpose: input.purpose,
        });
      }),
    update: protectedProcedure.input(z.object({
      id: z.number().int().positive(),
      purpose: z.enum(uploadPurposes).optional(),
      patientProfileId: z.number().int().positive().nullable().optional(),
      consentStatus: z.enum(["pending", "confirmed", "declined"]).optional(),
      consentNote: z.string().max(1000).nullable().optional(),
    })).mutation(({ ctx, input }) => updateStoredFile(ctx.user.id, input.id, {
      purpose: input.purpose,
      patientProfileId: input.patientProfileId,
      consentStatus: input.consentStatus,
      consentNote: input.consentNote,
      consentRecordedAt: input.consentStatus === "confirmed" ? new Date() : undefined,
    })),
    remove: protectedProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ ctx, input }) => removeStoredFile(ctx.user.id, input.id)),
  }),
});

export type AppRouter = typeof appRouter;
