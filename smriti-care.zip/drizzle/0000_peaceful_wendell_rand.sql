CREATE TABLE `patient_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`caregiverId` int NOT NULL,
	`preferredName` varchar(120) NOT NULL,
	`age` int,
	`background` text,
	`language` varchar(40) NOT NULL DEFAULT 'English',
	`childrenNames` text,
	`favouriteThings` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `patient_profiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `patient_profiles_caregiver_unique` UNIQUE(`caregiverId`)
);
--> statement-breakpoint
CREATE TABLE `stored_files` (
	`id` int AUTO_INCREMENT NOT NULL,
	`caregiverId` int NOT NULL,
	`patientProfileId` int,
	`fileKey` varchar(512) NOT NULL,
	`fileUrl` varchar(768) NOT NULL,
	`filename` varchar(255) NOT NULL,
	`mimeType` varchar(120) NOT NULL,
	`sizeBytes` int NOT NULL,
	`purpose` enum('memory-photo','voice-note','care-document','other') NOT NULL DEFAULT 'other',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `stored_files_id` PRIMARY KEY(`id`),
	CONSTRAINT `stored_files_fileKey_unique` UNIQUE(`fileKey`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`openId` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`loginMethod` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_openId_unique` UNIQUE(`openId`)
);
